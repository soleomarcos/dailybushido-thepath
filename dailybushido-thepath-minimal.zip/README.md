
# DailyBushido — The Path (Android, minimal import)

## Como abrir no Android Studio
1. Baixe e extraia este ZIP.
2. Android Studio > **Open** > selecione a pasta `dailybushido-thepath` extraída.
3. Aguarde o Sync. Se o Studio pedir atualizar Gradle/AGP, aceite.
4. Rode o app (`MainActivity`).

## Stack
- Kotlin, Jetpack Compose
- minSdk 24, targetSdk 35
- Compose BOM `2024.06.00`, Activity Compose `1.9.0`
